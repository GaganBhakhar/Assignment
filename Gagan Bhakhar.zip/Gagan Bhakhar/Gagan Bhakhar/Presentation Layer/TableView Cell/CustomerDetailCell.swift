//
//  CustomerDetailCell.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

class CustomerDetailCell: UITableViewCell {
    
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var emailIdLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    /// It configures the cell
    ///
    /// - Parameter customerModelDetail: It is the object of CustomerDetailModel
    func configureCell(customerModelDetail: CustomerDetailModel) {
        if customerModelDetail.fullName != "" {
            self.fullNameLabel.text = customerModelDetail.fullName
        } else {
            // extract name from email
        }
        self.emailIdLabel.text = customerModelDetail.emailId
        self.phoneNumberLabel.text = customerModelDetail.phoneNumber
    }
    /// This method returns the class name
    static func getIdentifier() -> String{
        return String(describing: self)
    }

}
