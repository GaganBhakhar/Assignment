//
//  SortCell.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

class SortCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    /// It configures the cell.
    ///
    /// - Parameter sortModelObj: It is the object of SortModel which contains the properties to configure the cell
    func configureCell(sortModelObj: SortModel) {
        self.textLabel?.text = sortModelObj.title
    }
    
    /// This method returns the class name.
    static func getIdentifier() -> String{
        return String(describing: self)
    }

}
