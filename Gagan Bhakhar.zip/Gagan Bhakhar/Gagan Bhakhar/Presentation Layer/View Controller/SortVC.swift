//
//  SortVC.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

protocol SortVCDelegate {
    func sortMethod(sortMethod: SortingMethods)
}

class SortVC: UIViewController {
    
    private let sortVM = SortVM()
    var delegate: SortVCDelegate?
    
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        sortVM.setSortModelList() 
        tableView.tableFooterView = UIView()
    }

}

extension SortVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sortVM.getNumberOfRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: SortCell.getIdentifier(), for: indexPath) as? SortCell {
            cell.configureCell(sortModelObj: sortVM.getSortObj(indexPath.row))
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        sortVM.setSortingMethod(index: indexPath.row)
        delegate?.sortMethod(sortMethod: sortVM.getSortingMethod())
    }
}
