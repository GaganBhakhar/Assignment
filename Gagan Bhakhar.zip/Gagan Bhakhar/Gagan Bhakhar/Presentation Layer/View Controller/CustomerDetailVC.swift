//
//  ViewController.swift
//  Gagan Bhakhar
//
//  Created by Gagan Bhakhar on 13/08/19.
//  Copyright © 2019 Gagan Bhakhar. All rights reserved.
//

import UIKit

class CustomerDetailVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var sortButton: UIBarButtonItem!
    
    private let customerDetailVM = CustomerDetailVM()
    
    @IBAction func sortButtonPressed(_ sender: Any) {
        if let controller = customerDetailVM.getVC() as? SortVC {
        controller.delegate = self
        controller.view.frame = CGRect(x: 300, y: 0, width: 120, height: 200)
        self.addVC(vc: controller)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        customerDetailVM.createDB { [weak self] (_ , error) in
            if error != nil {
                if let errorString = error {
                    self?.showAlert(title: AppConstants.Title.error, message: errorString)
                }
            }
        }
        
        customerDetailVM.createTable { [weak self] (_ , error) in
            if error != nil {
                if let errorString = error {
                    self?.showAlert(title: AppConstants.Title.error, message: errorString)
                }
            }
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        customerDetailVM.fetch { [weak self] (_, error) in
            if error == nil {
                print("Fetch Succed")
                self?.customerDetailVM.sortList()
                self?.tableView.reloadData()
            }
            else {
                if let errorString = error {
                    self?.showAlert(title: AppConstants.Title.error, message: errorString)
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let destVC = segue.destination as? CheckInVC else {
            return
        }
        destVC.delegate = self
        
    }
    
    /// Shows the alert
    ///
    /// - Parameters:
    ///   - title: Title of alert
    ///   - message: massage for alert
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
}
// MARK: TableViewDelegates and DataSource
extension CustomerDetailVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return customerDetailVM.numberOfRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        customerDetailVM.sortList()
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CustomerDetailCell.getIdentifier(), for: indexPath) as? CustomerDetailCell else {
            return UITableViewCell()
        }
        cell.configureCell(customerModelDetail: customerDetailVM.getSortedList()[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
            customerDetailVM.delete(index: indexPath.row) { [weak self] (_, error) in
                if error == nil {
                    print("Delete Succed")
                    tableView.reloadData()
                }
                else {
                    if let errorString = error {
                        self?.showAlert(title: AppConstants.Title.error, message: errorString)
                    }
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 68
    }
    
}

// MARK: CheckInProtocol
extension CustomerDetailVC: CheckInProtocol {
    
    func saveCustomerDetail(_ customerDetail: CustomerDetailModel, completionHandler: CompletionHandler) {
        customerDetailVM.save(customerDetail: customerDetail) { (_, error) in
            if error == nil {
                completionHandler?([], nil)
            } else {
                completionHandler?([], error)
            }
        }
    }
    
}

// MARK: Add and Remove VC
extension CustomerDetailVC {
    ///This method add a child view to parentview
    private func addVC(vc: UIViewController) {
        addChild(vc)
        self.view.addSubview(vc.view)
        vc.didMove(toParent: self)
    }
    
    /// This methos removes all the childrens of superview
    private func removeChildVC() {
        if self.children.count > 0{
            let viewControllers:[UIViewController] = self.children
            for viewContoller in viewControllers{
                viewContoller.willMove(toParent: nil)
                viewContoller.view.removeFromSuperview()
                viewContoller.removeFromParent()
            }
        }
    }
}

// MARK: UISearchBarDelegate
extension CustomerDetailVC: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        customerDetailVM.search(searchText: searchText)
        tableView.reloadData()
    }
}

// MARK: SortVCDelegate
extension CustomerDetailVC: SortVCDelegate {
    
    func sortMethod(sortMethod: SortingMethods) {
        self.removeChildVC()
        customerDetailVM.setSortingMethod(sortingMethod: sortMethod)
        tableView.reloadData()
    }
    
    
}
