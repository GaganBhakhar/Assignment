//
//  CheckInVC.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

protocol CheckInProtocol {
    /// This method save the details and get acknowledgement in completion handler
    ///
    /// - Parameters:
    ///   - customerDetail: It contains object of CustomerDetailModel
    ///   - completionHandler: It contains two arrguments first is array of CustomerDetailModel and second is String. If customerdetails save successfully the it contains empty array in first arrgument and nil in second arrgument otherwise it contains empty array in first arrgument and error string in second arrgument.
    func saveCustomerDetail(_ customerDetail: CustomerDetailModel, completionHandler: CompletionHandler)
}

class CheckInVC: UIViewController {
    
    @IBOutlet weak var fNameTF: UITextField!
    @IBOutlet weak var lNameTF: UITextField!
    @IBOutlet weak var emailIdTF: UITextField!
    @IBOutlet weak var pNumberTF: UITextField!
    @IBOutlet weak var checkInBtn: UIButton!
    
    var delegate: CheckInProtocol?
    private let checkInVM = CheckInVM()
    
    @IBAction func checkInBtnPressed(_ senderId: Any?) {
        if fNameTF.text != nil {
            if let isvalid = fNameTF.text?.isValidName(), !isvalid, fNameTF.text != "" {
                fNameTF.backgroundColor = #colorLiteral(red: 1, green: 0.7640424316, blue: 0.7328036817, alpha: 1)
                checkInVM.setFormFillCorrect(false)
                
            } else {
                fNameTF.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
                checkInVM.setFormFillCorrect(true)
                checkInVM.setFirstName(fNameTF.text ?? "")
            }
            viewDidLoad()
        }
        
        if lNameTF.text != nil {
            if let isvalid = lNameTF.text?.isValidName(), !isvalid, lNameTF.text != "" {
                lNameTF.backgroundColor = #colorLiteral(red: 1, green: 0.7640424316, blue: 0.7328036817, alpha: 1)
                checkInVM.setFormFillCorrect(false)
            } else {
                lNameTF.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
                checkInVM.setFormFillCorrect(true)
                checkInVM.setLastName(lNameTF.text ?? "")
            }
        }
        
        if emailIdTF.text != nil {
            if let isvalid = emailIdTF.text?.isValidEmail(), !isvalid {
                emailIdTF.backgroundColor = #colorLiteral(red: 1, green: 0.7640424316, blue: 0.7328036817, alpha: 1)
                checkInVM.setFormFillCorrect(false)
            } else {
                emailIdTF.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
                checkInVM.setFormFillCorrect(true)
                checkInVM.setEmailId(emailIdTF.text ?? "")
            }
        }
        
        if pNumberTF.text != nil {
            if let isvalid = pNumberTF.text?.isValidPhoneNumber(), !isvalid, pNumberTF.text != "" {
                pNumberTF.backgroundColor = #colorLiteral(red: 1, green: 0.7640424316, blue: 0.7328036817, alpha: 1)
                checkInVM.setFormFillCorrect(false)
            } else {
                pNumberTF.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
                checkInVM.setFormFillCorrect(true)
                checkInVM.setPhoneNumber(pNumberTF.text ?? "")
            }
        }
        
        if checkInVM.isFormFillCorrectly() {
            delegate?.saveCustomerDetail(checkInVM.getCustomerDetail(), completionHandler: { [weak self] (_, error) in
                if error == nil {
                    print("Save Succed")
                    self?.navigationController?.popViewController(animated: true)
                }
                else {
                    if let errorString = error {
                        self?.showAlert(title: AppConstants.Title.error, message: errorString)
                    }
                }
            })
            
        } else {
            self.showAlert(title: AppConstants.Title.validationError, message: AppConstants.Message.checkInVelidationError)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    /// Shows the alert
    ///
    /// - Parameters:
    ///   - title: Title of alert
    ///   - message: massage for alert
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

}

extension CheckInVC: UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        textField.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        return true
    }

}

