//
//  APIManager.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 15/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

class APIManager: NSObject {
//    func getRequest(with url: URL, callback: @escaping ([String: Any], String?) -> Swift.Void) -> Void {
//        
//        let defaultConfigObject = URLSessionConfiguration.default
//        defaultConfigObject.timeoutIntervalForRequest = 30.0
//        defaultConfigObject.timeoutIntervalForResource = 60.0
//        
//        let session = URLSession.init(configuration: defaultConfigObject, delegate: nil, delegateQueue: nil)
//        
//        var urlRequest = URLRequest(url: url as URL)
//        urlRequest.httpMethod = "GET"
//        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
//        session.dataTask(with: urlRequest, completionHandler: { (data, response, error) in
//            
//            guard let httpResponse: HTTPURLResponse = response as? HTTPURLResponse
//                else {
//                    print("Error: did not receive data")
//                    return
//            }
//            
//            var response : [String: Any]? = nil
//            
//            if httpResponse.statusCode == 200 {
//                print(httpResponse)
//                
//                guard let responseData = data else {
//                    print("Error: did not receive data")
//                    return
//                }
//                
//                do {
//                    let responseData = try JSONSerialization.jsonObject(with: responseData, options: [JSONSerialization.ReadingOptions.allowFragments]) as? [String : Any]
//                    
//                    response = responseData
//                    callback(response ?? [:], nil)
//                }
//                catch _ as NSError {
//                    
//                    callback(response ?? [:], nil)
//                    return
//                }
//            }
//            else {
//                print(httpResponse)
//                
//                guard error == nil else {
//                    print("error calling GET ")
//                    print(error ?? "error")
//                    callback([:], error?.localizedDescription)
//                    return
//                }
//                
//            }
//        }).resume()
//    }
//    
//    func postRequest(with url:URL, parameters:[String: Any], callback: @escaping ([String:Any], String?) -> Void) -> Void {
//        
//        let defaultConfigObject = URLSessionConfiguration.default
//        defaultConfigObject.timeoutIntervalForRequest = 30.0
//        defaultConfigObject.timeoutIntervalForResource = 60.0
//        
//        let session = URLSession.init(configuration: defaultConfigObject, delegate: nil, delegateQueue: nil)
//        
//        var urlRequest = URLRequest(url: url as URL)
//        urlRequest.httpMethod = "POST"
//        
//        do {
//            urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
//        } catch let error {
//            print(error.localizedDescription)
//        }
//        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
//        urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
//        
//        urlRequest.setValue("Postman-Token", forHTTPHeaderField: "93246e9e-1ab1-4bc2-ab49-dbae1504798d,f15d8cb8-6711-463a-bf40-8caead536dea")
//        
//        session.dataTask(with: urlRequest, completionHandler: { (data, urlResponse, error) in
//            
//            
//            guard let httpResponse:HTTPURLResponse = urlResponse as? HTTPURLResponse
//                else{
//                    print("did not get any data")
//                    return
//            }
//            var response : [String: Any]? = nil
//            
//            if httpResponse.statusCode == 200 {
//                
//                guard let responseData = data else {
//                    print("Error: did not receive data")
//                    return
//                }
//                
//                do {
//                    guard let responseData = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any] else {
//                        print("error trying to convert data to JSON")
//                        return
//                    }
//                    
//                    response = responseData
//                    callback(response ?? [:], nil)
//                } catch _ as NSError {
//                    callback(response ?? [:], nil)
//                    return
//                }
//            }
//                
//            else {
//                guard error == nil else {
//                    print("error calling GET on /todos/1")
//                    print(error ?? "error")
//                    callback([:], error?.localizedDescription)
//                    return
//                }
//            }
//        }).resume()
//    }
//    
//    func delete() {
//        
//    }
    
    /// With this method we hit the api and get the response in call back
    ///
    /// - Parameters:
    ///   - url: url of the Api
    ///   - httpMethod: http method of Api
    ///   - parameters: These are to make the http body
    ///   - callback: It contains two arrguments first is dictionary and second is String. If Api hits successfully then it contains response in first arrgument and nil in second arrgument otherwise it contains empty dictionary in first arrgument and error string in second arrgument
    func hitApi(with url:URL,_ httpMethod: HttpMethods,_ parameters:[String: Any] = [:], callback: @escaping ([String:Any], String?) -> Void) -> Void {
        let defaultConfigObject = URLSessionConfiguration.default
        defaultConfigObject.timeoutIntervalForRequest = 30.0
        defaultConfigObject.timeoutIntervalForResource = 60.0
        
        let session = URLSession.init(configuration: defaultConfigObject, delegate: nil, delegateQueue: nil)
        
        var urlRequest = URLRequest(url: url as URL)
        urlRequest.httpMethod = httpMethod.rawValue
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
        switch httpMethod {
        case .get:
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.addValue("application/json", forHTTPHeaderField: "Accept")
        case .post:
            do {
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            } catch let error {
                print(error.localizedDescription)
            }
            urlRequest.setValue("Postman-Token", forHTTPHeaderField: "93246e9e-1ab1-4bc2-ab49-dbae1504798d,f15d8cb8-6711-463a-bf40-8caead536dea")
        case .delete:
            do {
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        session.dataTask(with: urlRequest, completionHandler: { (data, urlResponse, error) in
            
            
            guard let httpResponse:HTTPURLResponse = urlResponse as? HTTPURLResponse
                else{
                    print("did not get any data")
                    return
            }
            var response : [String: Any]? = nil
            
            if httpResponse.statusCode == 200 {
                
                guard let responseData = data else {
                    print("Error: did not receive data")
                    return
                }
                
                do {
                    guard let responseData = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any] else {
                        print("error trying to convert data to JSON")
                        return
                    }
                    
                    response = responseData
                    callback(response ?? [:], nil)
                } catch _ as NSError {
                    callback(response ?? [:], nil)
                    return
                }
            }
                
            else {
                guard error == nil else {
                    print("error calling GET on /todos/1")
                    print(error ?? "error")
                    callback([:], error?.localizedDescription)
                    return
                }
            }
        }).resume()
    }
}
