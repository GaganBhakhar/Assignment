//
//  CheckInVM.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

class CheckInVM: NSObject {
    
    var firstName: String = ""
    var lastName: String = ""
    var emailId: String = ""
    var phoneNumber: String = ""
    var isFormFillCorrect: Bool = false
    
    private let coreDataManager = CoreDataManager()
    
    func setFirstName(_ str: String) {
        self.firstName = str
    }
    
    func setLastName(_ str: String) {
        self.lastName = str
    }
    
    func setEmailId(_ str: String) {
        self.emailId = str
    }
    
    func setPhoneNumber(_ str: String) {
        self.phoneNumber = str
    }
    
    func setFormFillCorrect(_ bool: Bool) {
        self.isFormFillCorrect = bool
    }
    
    func isFormFillCorrectly() -> Bool{
        return (self.firstName.count >= 0 && self.lastName.count >= 0 && self.emailId.count != 0 && self.phoneNumber.count >= 0)
    }
    
    func getCustomerDetail() -> CustomerDetailModel{
        return CustomerDetailModel(fullName: "\(firstName) \(lastName)", emailId: emailId, phoneNumber: phoneNumber)
    }
}
