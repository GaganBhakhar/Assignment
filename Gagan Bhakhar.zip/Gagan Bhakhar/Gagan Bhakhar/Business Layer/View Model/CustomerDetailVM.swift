//
//  CustomerDetailVM.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit
import CoreData

class CustomerDetailVM: NSObject {
    
    private var customerDetailList: [CustomerDetailModel] = []
    private var sortedCustomerDetailList: [CustomerDetailModel] = []
    private let customerDetailModel = CustomerDetailModel()
    private let coreDataManager = CoreDataManager()
    private let sqliteManager = SQLiteManager()
    private var sortingMethod: SortingMethods = .aToZ
    private let storyboard = UIStoryboard(name: "Main", bundle: nil)
    
//    func save(customerDetail: CustomerDetailModel, completionHandler: CompletionHandler) {
//
//        coreDataManager.save(customerDetail: customerDetail, completionHAndler: { [weak self] (customerList, error) in
//            if error == nil {
//                self?.customerDetailList.append(customerList.first ?? CustomerDetailModel())
//                completionHandler?([], nil)
//            }
//            else {
//                completionHandler?([], error)
//            }
//
//        })
////        let customerDtlMObj = coreDataManager.cnvrtNSMngdObjToCstmrDtlObj(nsManagedObj)
////        customerDetailList.append(customerDtlMObj)
//    }
    /// This method creates the database.
    ///
    /// - Parameter completionHandler: If database opens successfully then it contains empty array and nil otherwise it containsempty array and error string
    func createDB(completionHandler: CompletionHandler) {
        sqliteManager.createDB(completionHandler: { (customerList, error) in
            if error == nil {
                completionHandler?([], nil)
            }
            else {
                completionHandler?([], error)
            }
            
        })
    }
    
    /// creates the table.
    ///
    /// - Parameter completionHandler: completionHandler: If database opens successfully then it contains empty array and nil otherwise it containsempty array and error string
    func createTable(completionHandler: CompletionHandler) {
        sqliteManager.createTable(completionHandler: { (customerList, error) in
            if error == nil {
                completionHandler?([], nil)
            }
            else {
                completionHandler?([], error)
            }
            
        })
    }
    
    /// save the row in table.
    ///
    /// - Parameters:
    ///   - customerDetail: Customer details insert in row.
    ///   - completionHandler: completionHandler: If row insert successfully then it contains array of inserted object of CustomerDetailModel and nil otherwise it contains empty array and error string
    func save(customerDetail: CustomerDetailModel, completionHandler: CompletionHandler) {
        
        sqliteManager.insert(customerDetail: customerDetail, completionHandler: { [weak self] (customerList, error) in
            if error == nil {
                self?.customerDetailList.append(customerList.first ?? CustomerDetailModel())
                completionHandler?([], nil)
            }
            else {
                completionHandler?([], error)
            }
            
        })
        //        let customerDtlMObj = coreDataManager.cnvrtNSMngdObjToCstmrDtlObj(nsManagedObj)
        //        customerDetailList.append(customerDtlMObj)
    }
//    func fetch(completionHandler: CompletionHandler) {
//        coreDataManager.fetch { [weak self] (listMngdObj, error) in
//            if error == nil {
//                self?.customerDetailList = listMngdObj
//                completionHandler?([], nil)
//            } else {
//                completionHandler?([], error)
//            }
//        }
//
//    }
    /// Fetch all the data from table.
    ///
    /// - Parameter completionHandler: completionHandler: If query is right and succed then it contains array of CustomerDetailList and nil otherwise it contains empty array and error string
    func fetch(completionHandler: CompletionHandler) {
        sqliteManager.queryFetch { [weak self] (listMngdObj, error) in
            if error == nil {
                self?.customerDetailList = listMngdObj
                completionHandler?([], nil)
            } else {
                completionHandler?([], error)
            }
        }
        
    }
    
//    func delete(index: Int, completionHandler: CompletionHandler) {
//        let customerDetail = sortedCustomerDetailList[index]
//        coreDataManager.delete(customerObject: customerDetail) { [weak self] (customerList, error) in
//            if error == nil {
//                self?.customerDetailList.remove(at: index)
//                completionHandler?([], nil)
//            } else {
//                completionHandler?([], error)
//            }
//        }
//    }
    
    func delete(index: Int, completionHandler: CompletionHandler) {
        let customerDetail = sortedCustomerDetailList[index]
        sqliteManager.delete(customerDetail: customerDetail) { [weak self] (customerList, error) in
            if error == nil {
                self?.sortedCustomerDetailList.remove(at: index)
                completionHandler?([], nil)
            } else {
                completionHandler?([], error)
            }
        }
    }
    
    /// Return number of rows
    func numberOfRows() -> Int {
        return sortedCustomerDetailList.count
    }
    
    /// Return array of sorted customer detail list
    func getSortedList() -> [CustomerDetailModel] {
         return sortedCustomerDetailList
    }
    
    ///This method set sorting method
    func setSortingMethod(sortingMethod: SortingMethods) {
        self.sortingMethod = sortingMethod
    }
    
    ///This method sorts the list
    func sortList() {
        switch sortingMethod {
        
        case .aToZ:
            sortedCustomerDetailList = customerDetailList.sorted(by: {$0.fullName.trimmingCharacters(in: .whitespacesAndNewlines) < $1.fullName.trimmingCharacters(in: .whitespacesAndNewlines)})
        case .zToA:
            sortedCustomerDetailList = customerDetailList.sorted(by: {$0.fullName.trimmingCharacters(in: .whitespacesAndNewlines) > $1.fullName.trimmingCharacters(in: .whitespacesAndNewlines)})
        }
        
    }
    
    ///This method set the sarchList into sortedCustomerDetailList
    func search(searchText: String) {
        
        switch sortingMethod {
            
        case .aToZ:
            sortedCustomerDetailList = searchText.isEmpty ? customerDetailList.sorted(by: {$0.fullName.trimmingCharacters(in: .whitespacesAndNewlines) < $1.fullName.trimmingCharacters(in: .whitespacesAndNewlines)}) : customerDetailList.filter({(customerDetail) -> Bool in
                // If dataItem matches the searchText, return true to include it
                
                return (customerDetail.fullName.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil)
            })
        case .zToA:
            sortedCustomerDetailList = searchText.isEmpty ? customerDetailList.sorted(by: {$0.fullName.trimmingCharacters(in: .whitespacesAndNewlines) > $1.fullName.trimmingCharacters(in: .whitespacesAndNewlines)}) : customerDetailList.filter({(customerDetail) -> Bool in
                // If dataItem matches the searchText, return true to include it
                
                return (customerDetail.fullName.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil)
            })
        }
        
    }
    
    /// This method returns VC
    func getVC() -> UIViewController {
        if let controller = storyboard.instantiateViewController(withIdentifier: "SortVC") as? SortVC {
            return controller
        }
        return UIViewController()
    }
    
}
