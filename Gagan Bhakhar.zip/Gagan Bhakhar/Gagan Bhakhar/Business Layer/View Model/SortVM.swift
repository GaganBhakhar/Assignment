//
//  SortVM.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

class SortVM: NSObject {
    
    let sortModel = SortModel(title: "")
    var sortModelList: [SortModel] = []
    var sortingMethod: SortingMethods = .aToZ
    
    func setSortModelList() {
        sortModelList = sortModel.getSortObjectList()
    }
    
    func getNumberOfRows() -> Int{
        return sortModelList.count
    }
    
    func getSortObj(_ index: Int) -> SortModel{
        return sortModelList[index]
    }
    
    /// This method  set sorting method
    func setSortingMethod(index: Int) {
        switch index {
        case 0:
            sortingMethod = .aToZ
        case 1:
            sortingMethod = .zToA
        default:
            sortingMethod = .aToZ
        }
    }
    
    func getSortingMethod() -> SortingMethods {
        return sortingMethod
    }
    
}
