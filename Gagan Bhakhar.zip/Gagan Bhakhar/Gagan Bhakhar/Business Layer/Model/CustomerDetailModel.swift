//
//  CustomerDetailModel.swift
//  Gagan Bhakhar
//
//  Created by Gagan Bhakhar on 14/08/19.
//  Copyright © 2019 Gagan Bhakhar. All rights reserved.
//

import UIKit

class CustomerDetailModel: NSObject {
    
    var fullName: String = ""
    var emailId: String = ""
    var phoneNumber: String = ""
    
    override init() {
        
    }
    
    init(fullName: String, emailId: String, phoneNumber: String) {
        self.fullName = fullName
        self.emailId = emailId
        self.phoneNumber = phoneNumber
    }
    
}
