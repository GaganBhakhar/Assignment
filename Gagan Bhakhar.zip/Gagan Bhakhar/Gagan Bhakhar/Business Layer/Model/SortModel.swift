//
//  SortModel.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit

class SortModel: NSObject {
    
    var title: String = ""
    
    init(title: String) {
        self.title = title
    }
    
    func getSortObjectList() -> [SortModel] {
        let sortAToZ = SortModel(title: "A To Z")
        let sortZToA = SortModel(title: "Z To A")
        return [sortAToZ, sortZToA]
    }
}
