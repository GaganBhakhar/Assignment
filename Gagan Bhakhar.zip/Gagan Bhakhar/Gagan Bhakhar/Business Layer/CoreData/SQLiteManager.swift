//
//  SQLiteManager.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit
import SQLite3

class SQLiteManager: NSObject {
    
    private var completionHandler: CompletionHandler
    
    private var db: OpaquePointer?
    private var statement: OpaquePointer? = nil
    private var customerDetailList: [CustomerDetailModel] = []
    
    override init() {
        
    }
    
    /// This method creates the sqlite file and open's the database.
    ///
    /// - Parameter completionHandler: If database opens successfully then it contains empty array and nil otherwise it containsempty array and error string
    func createDB(completionHandler: CompletionHandler){
        let fileURL = try! FileManager.default.url(for: .documentDirectory,
                                                   in: .userDomainMask,
                                                   appropriateFor: nil, create: true)
            .appendingPathComponent("Detials.sqlite")
        print(fileURL)
        
        if (FileManager.default.fileExists(atPath: fileURL.path))
        {
            print("Successfull database create")
        }
        
        if sqlite3_open(fileURL.path, &db) == SQLITE_OK {
            print("Database successfull open")
            completionHandler?([], nil)
        }else {
            completionHandler?([], "error opening database")
        }
    }
    
    /// creates the table.
    ///
    /// - Parameter completionHandler: completionHandler: If database opens successfully then it contains empty array and nil otherwise it containsempty array and error string.
    func createTable(completionHandler: CompletionHandler) {
        
        let createTableString = "create table if not exists Customer (fullName text, emailId text, phoneNumber text)"
        
        // 2
        if sqlite3_prepare_v2(db, createTableString, -1, &statement, nil) == SQLITE_OK {
            // 3
            if sqlite3_step(statement) == SQLITE_DONE {
//                print("Customer table created.")
                completionHandler?([], nil)
            } else {
                print("Customer table could not be created.")
                completionHandler?([], "Customer table could not be created.")

            }
        } else {
            completionHandler?([], "CREATE TABLE statement could not be prepared.")
            print("CREATE TABLE statement could not be prepared.")
        }
        // 4
        sqlite3_finalize(statement)
    }
    
    /// Insert the row in table.
    ///
    /// - Parameters:
    ///   - customerDetail: Customer details insert in row.
    ///   - completionHandler: completionHandler: If row insert successfully then it contains array of inserted object of CustomerDetailModel and nil otherwise it contains empty array and error string
    func insert(customerDetail: CustomerDetailModel, completionHandler: CompletionHandler) {
        var statement: OpaquePointer?
        let insertStatementString = "insert into Customer (fullName, emailId, phoneNumber) VALUES (?,?,?)"
        let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
        
        // 1
        if sqlite3_prepare_v2(db, insertStatementString, -1, &statement, nil) == SQLITE_OK {
            
            if sqlite3_bind_text(statement, 1, customerDetail.fullName, -1, SQLITE_TRANSIENT) == SQLITE_OK {
                print("succed binding fullName")
            } else {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding fullName: \(errmsg)")
            }

            if sqlite3_bind_text(statement, 2, customerDetail.emailId, -1, SQLITE_TRANSIENT) == SQLITE_OK {
                print("succed binding emailId")
            } else {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding emailId: \(errmsg)")
            }

            if sqlite3_bind_text(statement, 3, customerDetail.phoneNumber, -1, SQLITE_TRANSIENT) == SQLITE_OK {
                print("succed binding phoneNumber")
            } else {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding phoneNumber: \(errmsg)")
            }

            
            
            // 4
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Successfully inserted row.")
                completionHandler?([customerDetail], nil)
            } else {
                print("Could not insert row.")
                completionHandler?([], "Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
            completionHandler?([], "INSERT statement could not be prepared.")
        }
        // 5
        sqlite3_finalize(statement)
    }
    
    /// Fetch all the data from table.
    ///
    /// - Parameter completionHandler: completionHandler: If query is right and succed then it contains array of CustomerDetailList and nil otherwise it contains empty array and error string.
    func queryFetch(completionHandler: CompletionHandler) {
        let queryStatementString = "SELECT * FROM Customer;"
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, queryStatementString, -1, &statement, nil) == SQLITE_OK {
            customerDetailList = []
            var  fullName = ""
            var emailId = ""
            var phoneNumber = ""
            while (sqlite3_step(statement) == SQLITE_ROW) {
                if let queryResultCol1 = sqlite3_column_text(statement, 0) {
                    fullName = String(cString: queryResultCol1)
                } else {
                    fullName = ""
                    
                }
                if let queryResultCol3 = sqlite3_column_text(statement, 1) {
                    emailId = String(cString: queryResultCol3)
                } else {
                    emailId = ""
                }
                if let queryResultCol4 = sqlite3_column_text(statement, 2) {
                    phoneNumber = String(cString: queryResultCol4)
                } else {
                    phoneNumber = ""
                }
                
                customerDetailList.append(CustomerDetailModel(fullName: fullName, emailId: emailId, phoneNumber: phoneNumber))
            }
            print("SELECT statement succed")
            completionHandler?(customerDetailList, nil)
            
        } else {
            print("SELECT statement could not be prepared")
            completionHandler?([], "SELECT statement could not be prepared")
        }
        sqlite3_finalize(statement)
    }
    
    /// Deletes the row from table.
    ///
    /// - Parameters:
    ///   - customerDetail: the object which you want to delete
    ///   - completionHandler: completionHandler: If delete succed then it contains empty array and nil otherwise it contains empty array and error string
    func delete(customerDetail: CustomerDetailModel, completionHandler: CompletionHandler) {
        let deleteStatementStirng = "DELETE FROM Customer WHERE emailId = ?"
        let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
        if sqlite3_prepare_v2(db, deleteStatementStirng, -1, &statement, nil) == SQLITE_OK {
            
            if sqlite3_bind_text(statement, 1, customerDetail.emailId, -1, SQLITE_TRANSIENT) == SQLITE_OK {
                print("succed binding emailId")
            } else {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding emailId: \(errmsg)")
            }
            
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Successfully deleted row.")
                completionHandler?([], nil)
            } else {
                print("Could not delete row.")
                completionHandler?([], "Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared.")
            completionHandler?([], "DELETE statement could not be prepared.")
        }
        
        sqlite3_finalize(statement)
    }
}
