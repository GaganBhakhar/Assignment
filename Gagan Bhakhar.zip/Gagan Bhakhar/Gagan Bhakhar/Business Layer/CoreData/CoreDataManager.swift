//
//  CoreDataManager.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import UIKit
import CoreData

class CoreDataManager: NSObject {
    
    var completionHandler: CompletionHandler
    
    let appDelegate =
        UIApplication.shared.delegate as? AppDelegate
    
    override init() {
        
    }
    func save(customerDetail: CustomerDetailModel, completionHAndler: CompletionHandler) {
        guard let appDelegate = appDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        let entity =
            NSEntityDescription.entity(forEntityName: "Customer",
                                       in: managedContext)!
        
        let customer = NSManagedObject(entity: entity,
                                     insertInto: managedContext)
        
        customer.setValue(customerDetail.fullName, forKeyPath: AppConstants.Keys.fullName)
        customer.setValue(customerDetail.emailId, forKeyPath: AppConstants.Keys.emailId)
        customer.setValue(customerDetail.phoneNumber, forKeyPath: AppConstants.Keys.phoneNumber)
        
        do {
            try managedContext.save()
            completionHAndler?([self.cnvrtNSMngdObjToCstmrDtlObj(customer)], nil)
//           return customer
        } catch let error as NSError {
//            print("Could not save. \(error), \(error.userInfo)")
            completionHAndler?([], "Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func fetch(completionHAndler: CompletionHandler) {
        guard let appDelegate = appDelegate else {
            return
        }
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Customer")
        
        //3
        do {
            let fetchData = try managedContext.fetch(fetchRequest)
            var customerList: [CustomerDetailModel] = []
            for mngdObj in fetchData {
                customerList.append(self.cnvrtNSMngdObjToCstmrDtlObj(mngdObj))
            }
            completionHAndler?(customerList, nil)
//            return try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            completionHAndler?([], "Could not fetch. \(error), \(error.userInfo)")
//            print("Could not fetch. \(error), \(error.userInfo)")
//            return []
        }
    }
    
    func delete(customerObject: CustomerDetailModel, completionHandler: CompletionHandler) {
        guard let appDelegate = appDelegate else {
            return
        }
        let managedContext =
            appDelegate.persistentContainer.viewContext
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Customer")
        fetchRequest.predicate = NSPredicate(format: "emailId == %@", "\(customerObject.emailId)")
        let objects = try! managedContext.fetch(fetchRequest)
        for obj in objects {
            managedContext.delete(obj)

        }
        do {
            try managedContext.save()
            completionHandler?([], nil)
        }
        catch let error as NSError {
            completionHandler?([], "Could not delete. \(error), \(error.userInfo)")
//            print("Could not delete. \(error), \(error.userInfo)")
        }
        
    }
}

extension CoreDataManager {
    
    func cnvrtNSMngdObjToCstmrDtlObj(_ nsMngdObj: NSManagedObject) -> CustomerDetailModel {
        
        let fullName = nsMngdObj.value(forKey: AppConstants.Keys.fullName) as! String
        let emailId = nsMngdObj.value(forKey: AppConstants.Keys.emailId) as! String
        let phoneNumber = nsMngdObj.value(forKey: AppConstants.Keys.phoneNumber) as! String
        
        return CustomerDetailModel(fullName: fullName,
                                   emailId: emailId,
                                   phoneNumber: phoneNumber)
    }
    
    func cnvrtCstmrDtlObjToNSMnngdObj(_ customerDtlObj: CustomerDetailModel) -> NSManagedObject{
        let nsManagedObj = NSManagedObject()
        nsManagedObj.setValue(customerDtlObj.fullName  , forKey: AppConstants.Keys.fullName)
        nsManagedObj.setValue(customerDtlObj.emailId    , forKey: AppConstants.Keys.emailId)
        nsManagedObj.setValue(customerDtlObj.phoneNumber, forKey: AppConstants.Keys.phoneNumber)
        return nsManagedObj
    }

}

