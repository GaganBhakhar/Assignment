//
//  Constants.swift
//  Gagan Bhakhar
//
//  Created by Gagan Bhakhar on 14/08/19.
//  Copyright © 2019 Gagan Bhakhar. All rights reserved.
//

import Foundation

typealias CompletionHandler = ((_ response: [CustomerDetailModel],_ error: String?) -> ())?

enum HttpMethods: String {
    case post = "POST"
    case get = "GET"
    case delete = "DELETE"
}

enum SortingMethods: Int {
    case aToZ = 0
    case zToA = 1
}

struct AppConstants {
    struct Keys {
        static let fullName = "fullName"
        static let emailId = "emailId"
        static let phoneNumber = "phoneNumber"
    }
    
    struct Title {
        static let error = "Error"
        static let validationError = "Validation Error"
    }
    
    struct Message {
        static let checkInVelidationError = "All fields are optional except email.\n\n First name and last name contains only alphabets \n\nEmail doesn't contain special characters except @. \n\n Phone Number starts from 6 to 9 and it contains 10 digits."
    }
}
