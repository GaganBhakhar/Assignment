//
//  Extension.swift
//  Gagan Bhakhar
//
//  Created by Jai Singh on 14/08/19.
//  Copyright © 2019 Jai Singh. All rights reserved.
//

import Foundation
import UIKit

extension String {
    func isValidEmail() -> Bool{
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let isValidEmail = emailPred.evaluate(with: self)
        return isValidEmail
    }
    
    func isValidPhoneNumber() -> Bool {
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phonePred = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phonePred.evaluate(with: self)
        return isValidPhone
    }
    
    func isValidName() -> Bool{
        let nameRegex = "[a-z A-Z ]+"  // {3} -> at least 3 alphabet are compulsory.
        let namePred = NSPredicate(format: "SELF MATCHES %@", nameRegex)
        let isValidName = namePred.evaluate(with: self)
        return isValidName
    }
    
}
